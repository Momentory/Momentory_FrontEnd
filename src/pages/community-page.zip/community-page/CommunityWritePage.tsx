import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ImagePlus} from "lucide-react";
import { postCommunity } from "../../api/community";
import { uploadFile } from "../../api/S3";

const GYEONGGI_REGIONS = [
  "수원시", "성남시", "고양시", "용인시", "부천시", "안산시", "안양시",
  "남양주시", "화성시", "평택시", "의정부시", "시흥시", "파주시",
  "김포시", "광명시", "광주시", "군포시", "이천시", "양주시", "오산시",
  "구리시", "안성시", "포천시", "의왕시", "하남시", "여주시",
  "양평군", "동두천시", "과천시", "가평군", "연천군", "기타"
];

const REGION_MAP: Record<string, number> = {
  수원시: 1,
  성남시: 2,
  고양시: 3,
  용인시: 4,
  부천시: 5,
  안산시: 6,
  안양시: 7,
  남양주시: 8,
  화성시: 9,
  평택시: 10,
  의정부시: 11,
  시흥시: 12,
  파주시: 13,
  김포시: 14,
  광명시: 15,
  광주시: 16,
  군포시: 17,
  이천시: 18,
  양주시: 19,
  오산시: 20,
  구리시: 21,
  안성시: 22,
  포천시: 23,
  의왕시: 24,
  하남시: 25,
  여주시: 26,
  양평군: 27,
  동두천시: 28,
  과천시: 29,
  가평군: 30,
  연천군: 31,
  기타: 99,
};


export default function CommunityWritePage() {
  const navigate = useNavigate();

  const [region, setRegion] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [tags, setTags] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);

  // 이미지 선택
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  // 게시하기
  const handleSubmit = async () => {
    if (!region || !title.trim() || !content.trim()) {
      alert("모든 필드를 입력해주세요!");
      return;
    }

    let imageUrl = "";
    let imageName = "";

    try {
      // 🔥 이미지 업로드 S3
      if (imageFile) {
        const uploaded = await uploadFile(imageFile);
        imageUrl = uploaded.result.imageUrl;
        imageName = uploaded.result.imageName;
      }

      const payload = {
        title,
        content,
        imageUrl,
        imageName,
        regionId: REGION_MAP[region],  
        tags: tags.split(" ").filter(Boolean),
      };

      const res = await postCommunity(payload);
      console.log("게시 성공:", res);

      alert("게시글이 등록되었습니다!");
      navigate("/community");

    } catch (err) {
      console.error("게시 실패:", err);
      alert("오류 발생. 다시 시도해주세요.");
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#F9FAFB] flex flex-col relative">

      {/* 🔥 1) 최상단 헤더 (메뉴 + 알림 + 유저) */}
      <header className="flex items-center justify-between bg-[#FF7070] text-white px-5 py-3">
        <div className="flex items-center gap-3">
          <img src="/images/menuIcon.png" className="w-[22px] h-[22px]" />
          <img src="/images/notificationIcon.png" className="w-[20px] h-[20px]" />
        </div>

        <div className="flex items-center gap-1 bg-white text-[#FF7070] px-3 py-[4px] rounded-full">
          <img src="/images/User.png" className="w-5 h-5" />
          <span className="text-[13px] font-medium">홍홍홍</span>
        </div>
      </header>

      {/* 🔥 2) 글쓰기 탑바 (글쓰기 / edit / user) */}
      <div className="flex items-center justify-between bg-white px-5 py-5 border-b">
        <h1 className="text-[25px] font-semibold">글쓰기</h1>

        <div className="flex items-center gap-4">
          <img src="/images/Edit.png" className="w-[25px]" />
          <img src="/images/User.png" className="w-[25px]" />
        </div>
      </div>

      {/* 🔥 3) 뒤로가기 + 게시 버튼 */}
      <div className="flex items-center justify-between bg-white px-5 py-3 mt-2 ">
        <button onClick={() => navigate(-1)}>
          <img
            src="/images/109618.png"
            alt="back"
            className="w-[28px] h-[28px]"
          />
        </button>

        <button
          onClick={handleSubmit}
          className="text-[#3D6AFF] text-[18px] font-semibold"
        >
          게시
        </button>
      </div>


      {/* 🔥 4) 업로드 이미지 영역 */}
      <div className="bg-white px-5 py-4 border-b">
        {preview ? (
          <img
            src={preview}
            className="w-full h-[370px] object-cover rounded-xl border"
          />
        ) : (
          <label className="flex flex-col items-center justify-center w-full h-[180px] border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:bg-gray-50 transition">
            <ImagePlus size={30} className="text-gray-400 mb-1" />
            <span className="text-gray-500 text-[14px] font-medium">
              사진 업로드
            </span>
            <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
          </label>
        )}
      </div>

      {/* 🔥 5) 입력폼 */}
      <div className="flex-1 bg-white px-5 py-5 space-y-5">

        <div>
          <label className="block text-[22px] font-semibold text-gray-800 mb-2">
            지역 선택
          </label>
          <select
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="w-full border border-gray-300 rounded-xl px-4 py-3 text-[13px]"
          >
            <option value="">지역을 선택해주세요</option>
            {GYEONGGI_REGIONS.map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[22px] font-semibold text-gray-800 mb-2">
            제목
          </label>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="제목을 입력해주세요..."
            className="w-full border border-gray-300 rounded-xl px-4 py-3 text-[13px]"
          />
        </div>

        <div>
          <label className="block text-[22px] font-semibold text-gray-800 mb-2">
            본문
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="본문을 입력해주세요..."
            className="w-full border border-gray-300 rounded-xl px-4 py-3 text-[13px] h-[130px] resize-none"
          />
        </div>

        <div>
          <label className="block text-[22px] font-semibold text-gray-800 mb-2">
            태그
          </label>
          <input
            value={tags}
            onChange={(e) => setTags(e.target.value)}
            placeholder="# 태그 입력"
            className="w-full border border-gray-300 rounded-xl px-4 py-3 text-[13px]"
          />
        </div>
      </div>

      <div className="h-[90px]" />
    </div>
  );
}
